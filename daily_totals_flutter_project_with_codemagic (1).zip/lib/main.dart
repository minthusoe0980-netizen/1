import 'dart:io';
import 'dart:typed_data';
import 'package:excel/excel.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:csv/csv.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'ส่งเงินรายวัน',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: const HomePage(),
    );
  }
}

class SheetInfo {
  final String name;
  final List<List<dynamic>> rows;
  SheetInfo(this.name, this.rows);
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  List<SheetInfo> sheets = [];
  bool loading = true;
  String status = 'กำลังโหลดไฟล์ Excel...';
  int selectedSheetIndex = 0;
  int? dateColIndex;
  int? amountColIndex;
  List<Map<String, dynamic>> dailyTotals = [];

  @override
  void initState() {
    super.initState();
    _loadExcelAsset();
  }

  Future<void> _loadExcelAsset() async {
    try {
      final bytes = await rootBundle.load('assets/ส่งเงิน 0-24.xlsx');
      final Uint8List list = bytes.buffer.asUint8List();
      var excel = Excel.decodeBytes(list);

      List<SheetInfo> tmp = [];
      for (var sheetName in excel.tables.keys) {
        var table = excel.tables[sheetName]!;
        // Convert rows (keeping raw values)
        List<List<dynamic>> rows = table.rows.map((r) => r.map((c) => c?.value).toList()).toList();
        tmp.add(SheetInfo(sheetName, rows));
      }

      setState(() {
        sheets = tmp;
        loading = false;
        status = 'โหลดไฟล์เสร็จ — พบ ${sheets.length} sheet';
      });
    } catch (e) {
      setState(() {
        loading = false;
        status = 'เกิดข้อผิดพลาดในการอ่านไฟล์: $e';
      });
    }
  }

  /// พรีวิวแถว (แสดง 10 แถวแรก)
  List<List<String>> previewRows() {
    if (sheets.isEmpty) return [];
    var rows = sheets[selectedSheetIndex].rows;
    int count = rows.length < 10 ? rows.length : 10;
    return List.generate(count, (i) {
      return rows[i].map((c) => c == null ? '' : c.toString()).toList();
    });
  }

  /// แยกข้อมูลตามคอลัมน์ที่ผู้ใช้เลือก แล้วคำนวณยอดรวมต่อวัน
  void computeDailyTotals() {
    dailyTotals.clear();
    if (sheets.isEmpty) return;
    if (dateColIndex == null || amountColIndex == null) {
      setState(() {
        status = 'โปรดเลือกคอลัมน์วันที่และยอดเงินก่อน';
      });
      return;
    }

    final rows = sheets[selectedSheetIndex].rows;
    Map<String, double> map = {};

    for (var r in rows) {
      if (r.length <= dateColIndex! || r.length <= amountColIndex!) continue;
      var rawDate = r[dateColIndex!];
      var rawAmt = r[amountColIndex!];
      if (rawDate == null || rawAmt == null) continue;

      DateTime? parsedDate = _tryParseDate(rawDate);
      double? amt = _tryParseAmount(rawAmt);
      if (parsedDate == null || amt == null) continue;
      String key = DateFormat('yyyy-MM-dd').format(parsedDate);
      map[key] = (map[key] ?? 0) + amt;
    }

    var list = map.entries.map((e) => {'date': e.key, 'total_amount': e.value}).toList();
    list.sort((a, b) => b['date'].compareTo(a['date']));
    setState(() {
      dailyTotals = list;
      status = 'คำนวณเสร็จ — พบ ${dailyTotals.length} วัน';
    });
  }

  DateTime? _tryParseDate(dynamic raw) {
    try {
      if (raw is DateTime) return raw;
      String s = raw.toString().trim();
      // หลายรูปแบบ: yyyy-mm-dd, dd/mm/yyyy, dd-mm-yyyy, dd/mm/yy, etc.
      // พยายาม parse หลายกรณี
      // 1) ISO
      try {
        return DateTime.parse(s);
      } catch (_) {}
      // 2) dd/mm/yyyy or dd-mm-yyyy
      RegExp re = RegExp(r'(\\d{1,2})[\\/\\-](\\d{1,2})[\\/\\-](\\d{2,4})');
      var m = re.firstMatch(s);
      if (m != null) {
        int d = int.parse(m.group(1)!);
        int mo = int.parse(m.group(2)!);
        int y = int.parse(m.group(3)!);
        if (y < 100) y += 2000;
        return DateTime(y, mo, d);
      }
      // 3) ถ้าเป็นตัวเลข (Excel serial date)
      if (double.tryParse(s) != null) {
        double v = double.parse(s);
        // Excel's epoch: 1899-12-30 (approx): convert if reasonable
        DateTime base = DateTime(1899, 12, 30);
        return base.add(Duration(days: v.floor()));
      }
      // ไม่สำเร็จ
      return null;
    } catch (e) {
      return null;
    }
  }

  double? _tryParseAmount(dynamic raw) {
    try {
      if (raw is num) return raw.toDouble();
      String s = raw.toString().replaceAll(',', '').replaceAll('฿', '').replaceAll('\\$', '').trim();
      if (s == '') return null;
      return double.tryParse(s);
    } catch (e) {
      return null;
    }
  }

  Future<void> exportCsvAndShare() async {
    if (dailyTotals.isEmpty) return;
    List<List<dynamic>> rows = [
      ['date', 'total_amount'],
      ...dailyTotals.map((r) => [r['date'], r['total_amount']])
    ];
    String csv = const ListToCsvConverter().convert(rows);
    final dir = await getTemporaryDirectory();
    final file = File('${dir.path}/daily_totals.csv');
    await file.writeAsString(csv, encoding: const Utf8Codec());
    await Share.shareXFiles([XFile(file.path)], text: 'Daily totals CSV');
  }

  @override
  Widget build(BuildContext context) {
    final preview = previewRows();
    final sheetNames = sheets.map((s) => s.name).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('สรุปยอดรวมรายวัน')),
      body: Padding(
        padding: const EdgeInsets.all(12.0),
        child: loading
            ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: const [CircularProgressIndicator(), SizedBox(height:8), Text('กำลังโหลดไฟล์...')]))
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(status),
                  const SizedBox(height: 12),
                  if (sheetNames.isNotEmpty) ...[
                    const Text('เลือก Sheet:'),
                    DropdownButton<int>(
                      value: selectedSheetIndex,
                      items: List.generate(sheetNames.length, (i) => DropdownMenuItem(value: i, child: Text(sheetNames[i].toString()))),
                      onChanged: (v) { if (v!=null) setState(()=> selectedSheetIndex = v); },
                    ),
                    const SizedBox(height: 8),
                    const Text('ตัวอย่างข้อมูล (แถวบนสุด):'),
                    const SizedBox(height: 6),
                    SingleChildScrollView(
                      scrollDirection: Axis.horizontal,
                      child: DataTable(
                        columns: List.generate(
                          preview.isNotEmpty ? preview[0].length : 1,
                          (i) => DataColumn(label: Text('C$i')),
                        ),
                        rows: preview.map((r) => DataRow(cells: r.map((c)=> DataCell(Text(c))).toList())).toList(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Expanded(
                          child: TextFormField(
                            initialValue: dateColIndex?.toString() ?? '',
                            decoration: const InputDecoration(labelText: 'คอลัมน์วันที่ (index เริ่ม 0)'),
                            keyboardType: TextInputType.number,
                            onChanged: (v) {
                              setState(() {
                                dateColIndex = v.trim()==''? null : int.tryParse(v);
                              });
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextFormField(
                            initialValue: amountColIndex?.toString() ?? '',
                            decoration: const InputDecoration(labelText: 'คอลัมน์ยอดเงิน (index เริ่ม 0)'),
                            keyboardType: TextInputType.number,
                            onChanged: (v) {
                              setState(() {
                                amountColIndex = v.trim()==''? null : int.tryParse(v);
                              });
                            },
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 10),
                    Row(
                      children: [
                        ElevatedButton.icon(onPressed: computeDailyTotals, icon: const Icon(Icons.calculate), label: const Text('คำนวณยอดรวมรายวัน')),
                        const SizedBox(width: 12),
                        ElevatedButton.icon(
                          onPressed: dailyTotals.isEmpty ? null : exportCsvAndShare,
                          icon: const Icon(Icons.share),
                          label: const Text('ส่งออก CSV / แชร์'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                  ],
                  const Divider(),
                  const Text('ผลลัพธ์ — ยอดรวมรายวัน:'),
                  const SizedBox(height: 8),
                  Expanded(
                    child: dailyTotals.isEmpty
                        ? const Center(child: Text('ยังไม่มีข้อมูลสรุป — กดปุ่มคำนวณข้างบน'))
                        : ListView.builder(
                            itemCount: dailyTotals.length,
                            itemBuilder: (context, idx) {
                              final r = dailyTotals[idx];
                              return ListTile(
                                leading: Text((idx+1).toString()),
                                title: Text(r['date']),
                                trailing: Text(NumberFormat('#,##0.00').format(r['total_amount'])),
                              );
                            },
                          ),
                  ),
                ],
              ),
      ),
    );
  }
}