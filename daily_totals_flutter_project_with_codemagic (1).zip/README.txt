Daily Totals Flutter Project
===========================

This bundle contains a minimal Flutter app that reads the embedded Excel file
`assets/ส่งเงิน 0-24.xlsx`, allows selecting a sheet and mapping the date & amount
columns, and computes daily totals shown as a table. The app is named "ส่งเงินรายวัน".

Files included:
- lib/main.dart           (Flutter app)
- pubspec.yaml            (dependencies & asset)
- assets/ส่งเงิน 0-24.xlsx (your uploaded Excel file)

How to build an Android APK (requires a computer with Flutter SDK installed):
1. Install Flutter: https://flutter.dev/docs/get-started/install
2. Extract this project and open a terminal in the project folder.
3. Run: `flutter pub get`
4. To build a debug APK: `flutter build apk --debug`
   Or release APK: `flutter build apk --release`
5. The generated APK will be at: `build/app/outputs/flutter-apk/app-release.apk` (release) or app-debug.apk

If you do NOT have a computer, here are options:
- Ask someone with a computer to run the above steps and send you the APK file.
- Use a cloud CI service that builds Flutter apps (e.g., Codemagic, GitHub Actions) — I can help prepare the CI config for automatic APK builds.
- Alternatively, I can convert the app to a web app you can open in your phone browser (no install required), or prepare a Google Sheet-based summary.

Notes:
- The project expects the embedded Excel file to be in `assets/ส่งเงิน 0-24.xlsx`.
- If the Excel structure varies, open the app, select the sheet, preview the rows and input the column indexes (0-based) for the date and amount, then press the calculate button.

If you'd like, I can also prepare a GitHub repository and a GitHub Actions workflow that builds the APK automatically and uploads it as a release artifact — tell me and I'll include the workflow file.